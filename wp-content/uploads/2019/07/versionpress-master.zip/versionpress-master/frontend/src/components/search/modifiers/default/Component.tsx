import ListComponent from '../list/Component';

export default ListComponent;

/*
import * as React from 'react';

import ModifierComponent from '../ModifierComponent';

export default class DefaultComponent extends ModifierComponent {

  render() {
    return <div>Default Component</div>;
  }

};
*/
